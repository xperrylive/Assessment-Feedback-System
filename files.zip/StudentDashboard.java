import javax.swing.*;
import java.awt.*;

/**
 * StudentDashboard - Placeholder for Part 3
 * Will implement:
 * - Register for classes
 * - View results and feedback
 * - Edit profile
 */
public class StudentDashboard extends JFrame {
    
    public StudentDashboard() {
        setTitle("Student Dashboard - Assessment Feedback System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel label = new JLabel("Student Dashboard - Coming in Part 3", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 24));
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> {
            Session.getInstance().logout();
            new LoginFrame().setVisible(true);
            dispose();
        });
        
        panel.add(label, BorderLayout.CENTER);
        panel.add(logoutButton, BorderLayout.SOUTH);
        
        add(panel);
    }
}
